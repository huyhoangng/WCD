package com.example.practicalexamwcd.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Indexer {
    private Long Id;
    private String name;
    private float valueMin;
    private float valueMax;
}
