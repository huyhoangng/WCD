package com.example.practicalexamwcd.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class PlayerIndex {
    private int id;
    private int playerId;
    private int indexId;
    private float value;
}
