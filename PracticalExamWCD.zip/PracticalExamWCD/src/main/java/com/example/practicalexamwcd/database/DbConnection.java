package com.example.practicalexamwcd.database;

import java.sql.*;

public class DbConnection {

        private static final String JDBC_URL = "jdbc:mysql://localhost:3306/player_evaluation";
    private final String user = "root";
    private final String password = "root";
    private final String driver = "com.mysql.cj.jdbc.Driver";

    //singleton pattern
    private static DbConnection _instance;
    private Connection conn;
    private DbConnection() {
        try {
            Class.forName(driver); // Load the driver
            conn = DriverManager.getConnection(conectionString,user,password);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Failed to load database driver: " + driver, e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static DbConnection createInstance() {
        if (_instance == null) {
            synchronized (DbConnection.class) {
                if (_instance == null) {
                    _instance = new DbConnection();
                }
            }
        }
        return _instance;
    }
    public Statement getStatement() throws SQLException{
        return conn.createStatement();
    }
    public PreparedStatement getPreparedStatement(String sql) throws SQLException {
        return conn.prepareStatement(sql);
    }
    public Connection getConnection() {
        return conn;
    }
}
